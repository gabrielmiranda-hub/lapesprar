Core/Src/main.o: ../Core/Src/main.c ../Core/Inc/main.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h \
 ../Core/Inc/stm32f4xx_hal_conf.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f401xe.h \
 ../Drivers/CMSIS/Include/core_cm4.h \
 ../Drivers/CMSIS/Include/cmsis_version.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h \
 ../Drivers/CMSIS/Include/mpu_armv7.h \
 ../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_spi.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_system.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_gpio.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_exti.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_bus.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_cortex.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_rcc.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_utils.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_pwr.h \
 ../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_dma.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h \
 ../Core/Inc/FreeRTOSConfig.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/task.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/include/list.h \
 ../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h \
 ../Core/Inc/lora.h ../Core/Inc/debug_macro.h ../Core/Inc/lapesp-types.h \
 ../Core/Inc/lapesp-protocol.h ../Core/Inc/sensor-data.h \
 ../Core/Inc/BNO080.h ../Core/Inc/main.h ../Core/Inc/BME280_STM32.h \
 ../Core/Inc/flight_state.h
../Core/Inc/main.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal.h:
../Core/Inc/stm32f4xx_hal_conf.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_def.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f4xx.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/stm32f401xe.h:
../Drivers/CMSIS/Include/core_cm4.h:
../Drivers/CMSIS/Include/cmsis_version.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
../Drivers/CMSIS/Include/mpu_armv7.h:
../Drivers/CMSIS/Device/ST/STM32F4xx/Include/system_stm32f4xx.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/Legacy/stm32_hal_legacy.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_rcc_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_gpio_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_dma_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_flash_ramfunc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_i2c_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_pwr_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_tim_ex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_hal_uart.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_spi.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_system.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_gpio.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_exti.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_bus.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_cortex.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_rcc.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_utils.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_pwr.h:
../Drivers/STM32F4xx_HAL_Driver/Inc/stm32f4xx_ll_dma.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/FreeRTOS.h:
../Core/Inc/FreeRTOSConfig.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/projdefs.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/portable.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/deprecated_definitions.h:
../Middlewares/Third_Party/FreeRTOS/Source/portable/GCC/ARM_CM4F/portmacro.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/mpu_wrappers.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/task.h:
../Middlewares/Third_Party/FreeRTOS/Source/include/list.h:
../Middlewares/Third_Party/FreeRTOS/Source/CMSIS_RTOS_V2/cmsis_os2.h:
../Core/Inc/lora.h:
../Core/Inc/debug_macro.h:
../Core/Inc/lapesp-types.h:
../Core/Inc/lapesp-protocol.h:
../Core/Inc/sensor-data.h:
../Core/Inc/BNO080.h:
../Core/Inc/main.h:
../Core/Inc/BME280_STM32.h:
../Core/Inc/flight_state.h:
