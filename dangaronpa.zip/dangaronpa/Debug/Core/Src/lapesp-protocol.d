Core/Src/lapesp-protocol.o: ../Core/Src/lapesp-protocol.c \
 ../Core/Inc/lapesp-protocol.h
../Core/Inc/lapesp-protocol.h:
