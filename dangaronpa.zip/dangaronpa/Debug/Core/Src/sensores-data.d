Core/Src/sensores-data.o: ../Core/Src/sensores-data.c \
 ../Core/Inc/sensor-data.h
../Core/Inc/sensor-data.h:
